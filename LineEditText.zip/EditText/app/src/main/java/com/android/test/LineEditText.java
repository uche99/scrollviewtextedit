package com.android.test;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.EditText;
import android.graphics.Rect;
import android.graphics.Paint;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.graphics.Color;


public class LineEditText extends EditText {
   
    private Rect rect;
    private Paint paint;
    private int paddingLeft=50;
    

    public LineEditText(Context context) {
        super(context);
        initialize();
    }

    public LineEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        initialize();
    }

    public LineEditText(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initialize();
    }

    private void initialize() {
        rect = new Rect();
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.BLACK);
        paint.setTextSize(20);
        paint.setTypeface(Typeface.MONOSPACE);
        
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }


    @Override
    protected void onDraw(Canvas canvas) {

        int baseline;
        int lineCount = getLineCount();
        int lineNumber = 1;

        for (int i = 0; i < lineCount; ++i) 
        {
            baseline=getLineBounds(i, null);
            if (i == 0) 
            {
                canvas.drawText(""+lineNumber, rect.left,baseline, paint);
                ++lineNumber;
            } 
            else if (getText().charAt(getLayout().getLineStart(i) - 1) == '\n') 
            {
                canvas.drawText(""+lineNumber, rect.left,baseline, paint);
                ++lineNumber;
            }
        }   


// for setting edittext start padding
        if(lineCount<100)
        {
            setPadding(paddingLeft,getPaddingTop(),getPaddingRight(),getPaddingBottom());
        }
        else if(lineCount>99 && lineCount<1000)
        {
            setPadding(paddingLeft,getPaddingTop(),getPaddingRight(),getPaddingBottom());
        }
        else if(lineCount>999 && lineCount<10000)
        {
            setPadding(paddingLeft,getPaddingTop(),getPaddingRight(),getPaddingBottom());
        }
        else if(lineCount>9999 && lineCount<100000)
        {
            setPadding(paddingLeft,getPaddingTop(),getPaddingRight(),getPaddingBottom());
        }

        super.onDraw(canvas);
    }
    
    
}
