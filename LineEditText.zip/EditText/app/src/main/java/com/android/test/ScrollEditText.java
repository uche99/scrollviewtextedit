package com.android.test;
import android.widget.HorizontalScrollView;
import android.content.Context;
import android.util.AttributeSet;
import android.widget.ScrollView;
import android.view.LayoutInflater;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.ScaleGestureDetector;

public class ScrollEditText extends HorizontalScrollView
{
    private ScrollView verticalScroll;
    private LineEditText lineEditText;
    public int VERTICAL_SCROLL_ID = 0x7ff9;
    public int EDIT_TEXT_ID = 0x7fff;
    private int textSize=14;
    private int textColor=0xff000000;
    
    private boolean STYLE_BOLD=false;
    private boolean STYLE_ITALIC=false;
    private String text;
    private boolean SINGLE_LINE=false;
    private String MULTILINE="textMultiLine";
    
    public ScrollEditText(Context context){
        super(context);
        initialize(context);
        
    }
    public ScrollEditText(Context context,AttributeSet attrs){
        super(context,attrs);
        initialize(context);
        initAttributes(context,attrs,0);
    }
    public ScrollEditText(Context context,AttributeSet attrs,int defStyle){
        super(context,attrs,defStyle);
        initAttributes(context,attrs,defStyle);
        initialize(context);
    }
    private void initialize(Context context){
        verticalScroll = new ScrollView(context);
        lineEditText = new LineEditText(context);
        lineEditText.setId(EDIT_TEXT_ID);
        verticalScroll.setId(VERTICAL_SCROLL_ID);
        verticalScroll.addView(lineEditText);
        addView(verticalScroll);
        
    }
    
    public ScrollView getVerticalScrollView(){
        return verticalScroll;
    }
    
    public LineEditText getLineEditText(){
        return lineEditText;
    }
    
    private void initAttributes(Context context, AttributeSet attrs, int defStyle) {
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.ScrollEditText );
        final int N = a.getIndexCount();
        for (int i = 0; i < N; ++i) {
            int attr = a.getIndex(i);
            switch (attr) {
                case R.styleable.ScrollEditText_textColor:
                    textColor = a.getColor(attr,0);
                    lineEditText.setTextColor(textColor);
                    break;
                case R.styleable.ScrollEditText_textSize:
                    textSize = a.getDimensionPixelSize(attr, 0);
                    lineEditText.setTextSize(textSize);
                    break;
                case R.styleable.ScrollEditText_textBold:
                    STYLE_BOLD=a.getBoolean(R.styleable.ScrollEditText_textBold,false);
                    TextStyle();
                    break;
                case R.styleable.ScrollEditText_textItalic:
                    STYLE_ITALIC=a.getBoolean(R.styleable.ScrollEditText_textItalic,false);
                    TextStyle();
                    break;
                case R.styleable.ScrollEditText_text:
                    text=a.getString(R.styleable.ScrollEditText_text);
                    lineEditText.setText(text);
                    
                    break;
                case R.styleable.ScrollEditText_singleLine:
                    SINGLE_LINE=a.getBoolean(R.styleable.ScrollEditText_singleLine,false);
                    //if(SINGLE_LINE)lineEditText.setSingleLine();
                    break;
                
            }
        }
        a.recycle();
    }
    
    private void TextStyle(){
        if(STYLE_BOLD){
            lineEditText.setTypeface(null,Typeface.BOLD);
        }else if(STYLE_ITALIC){
            lineEditText.setTypeface(null,Typeface.ITALIC);
          
        }
    }
}
