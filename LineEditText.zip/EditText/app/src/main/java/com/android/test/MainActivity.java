package com.android.test;

import android.app.*;
import android.os.*;

import android.os.Bundle;
import android.view.View;
import android.content.Context;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.util.Log;
import android.widget.EditText;

public class MainActivity extends Activity
{
    ScrollEditText scroll;
    EditText edit;
    String textData="";
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        // TODO: Implement this method
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_text);
        getActionBar().hide();
        scroll=(ScrollEditText)findViewById(R.id.edit_text1);
        edit=scroll.getLineEditText();
        byte[] a=new byte[300];
        try{
            for(int i=0;i<a.length;i++){
                a[i]=(byte)(i+96);
            }
            for(int x=0;x<300;x++){
                textData+=(new String(a)+(x+1)+"\n");
                
            }
        }catch(Exception e){
            textData+=e.toString();
        }
        
        edit.setText(textData);
        
    }
    
    
}
